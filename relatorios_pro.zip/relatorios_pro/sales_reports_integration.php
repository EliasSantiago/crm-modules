<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Add Relatorios Pro to Sales Reports page
 */
function relatoriospro_add_to_sales_reports()
{
    if (!relatoriospro_can('view')) {
        return;
    }
    
    // Only add to sales reports page
    $CI = &get_instance();
    $current_uri = $CI->uri->segment(1) . '/' . $CI->uri->segment(2);
    
    if ($current_uri !== 'admin/reports' && $current_uri !== 'admin/reports/sales') {
        return;
    }
    
    echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Find the sales reports container
        var reportsContainer = document.querySelector(".row .col-md-12");
        if (reportsContainer) {
            // Create Relatorios Pro section
            var relatoriosProSection = document.createElement("div");
            relatoriosProSection.innerHTML = `
                <div class="col-md-12">
                    <div class="panel_s">
                        <div class="panel-body">
                            <h4 class="no-margin">Relatórios Pro - Análise Detalhada de Itens</h4>
                            <hr class="hr-panel-heading" />
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="panel_s">
                                        <div class="panel-body text-center">
                                            <h3><i class="fa fa-file-invoice-dollar text-primary"></i></h3>
                                            <h4>Relatório de Faturas</h4>
                                            <p>Análise detalhada de itens em faturas</p>
                                            <a href="' . admin_url('relatoriospro/invoices') . '" class="btn btn-primary">
                                                <i class="fa fa-chart-line"></i> Ver Relatório
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="panel_s">
                                        <div class="panel-body text-center">
                                            <h3><i class="fa fa-file-lines text-info"></i></h3>
                                            <h4>Relatório de Orçamentos</h4>
                                            <p>Análise detalhada de itens em orçamentos</p>
                                            <a href="' . admin_url('relatoriospro/estimates') . '" class="btn btn-info">
                                                <i class="fa fa-chart-line"></i> Ver Relatório
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="panel_s">
                                        <div class="panel-body text-center">
                                            <h3><i class="fa fa-handshake text-success"></i></h3>
                                            <h4>Relatório de Propostas</h4>
                                            <p>Análise detalhada de itens em propostas</p>
                                            <a href="' . admin_url('relatoriospro/proposals') . '" class="btn btn-success">
                                                <i class="fa fa-chart-line"></i> Ver Relatório
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Insert after existing content
            reportsContainer.appendChild(relatoriosProSection);
        }
    });
    </script>';
}

// Add to sales reports page
hooks()->add_action('admin_footer', 'relatoriospro_add_to_sales_reports');
