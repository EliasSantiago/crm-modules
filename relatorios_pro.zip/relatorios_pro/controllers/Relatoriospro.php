<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Relatoriospro extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('relatoriospro_model');
        $this->load->helper('relatoriospro/relatoriospro');
    }

    public function index()
    {
        if (!relatoriospro_can('view')) access_denied('relatoriospro');
        $data['title'] = _l('relatoriospro_title');
        $this->load->view('partials/landing', $data);
    }

    public function invoices()
    {
        if (!relatoriospro_can('view')) access_denied('relatoriospro');
        $data['title'] = _l('relatoriospro_invoices_report');
        $this->load->view('invoices/index', $data);
    }

    public function estimates()
    {
        if (!relatoriospro_can('view')) access_denied('relatoriospro');
        $data['title'] = _l('relatoriospro_estimates_report');
        $this->load->view('estimates/index', $data);
    }

    public function proposals()
    {
        if (!relatoriospro_can('view')) access_denied('relatoriospro');
        $data['title'] = _l('relatoriospro_proposals_report');
        $this->load->view('proposals/index', $data);
    }

    public function settings()
    {
        if (!is_admin()) access_denied('relatoriospro_settings');
        if ($this->input->post()) {
            update_option('relatoriospro_enabled', $this->input->post('relatoriospro_enabled') ? '1' : '0');
            set_alert('success', _l('settings_updated'));
            redirect(admin_url('relatoriospro/settings'));
        }
        $data['title'] = _l('settings');
        $this->load->view('partials/settings', $data);
    }
}
