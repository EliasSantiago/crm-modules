<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro Controller
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */
class Relatoriospro extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('relatoriospro_model');
        $this->load->helper('relatoriospro/relatoriospro');
        
        // Load required models for filters
        $this->load->model('clients_model');
        $this->load->model('staff_model');
        $this->load->model('payment_modes_model');
    }

    /**
     * Main dashboard
     */
    public function index()
    {
        if (!relatoriospro_can('view')) {
            access_denied('relatoriospro');
        }
        
        $data['title'] = _l('relatoriospro_title');
        $this->load->view('partials/landing', $data);
    }

    /**
     * Invoices report
     */
    public function invoices()
    {
        if (!relatoriospro_can('view')) {
            access_denied('relatoriospro');
        }
        
        $data['title'] = _l('relatoriospro_invoices_report');
        $data['clients'] = $this->clients_model->get();
        $data['staff'] = $this->staff_model->get();
        $data['payment_modes'] = $this->payment_modes_model->get();
        $data['items'] = $this->relatoriospro_model->get_unique_items();
        
        $this->load->view('invoices/index', $data);
    }

    /**
     * Estimates report
     */
    public function estimates()
    {
        if (!relatoriospro_can('view')) {
            access_denied('relatoriospro');
        }
        
        $data['title'] = _l('relatoriospro_estimates_report');
        $data['clients'] = $this->clients_model->get();
        $data['staff'] = $this->staff_model->get();
        $data['items'] = $this->relatoriospro_model->get_unique_items();
        
        $this->load->view('estimates/index', $data);
    }

    /**
     * Proposals report
     */
    public function proposals()
    {
        if (!relatoriospro_can('view')) {
            access_denied('relatoriospro');
        }
        
        $data['title'] = _l('relatoriospro_proposals_report');
        $data['clients'] = $this->clients_model->get();
        $data['staff'] = $this->staff_model->get();
        $data['items'] = $this->relatoriospro_model->get_unique_items();
        
        $this->load->view('proposals/index', $data);
    }

    /**
     * Module settings
     */
    public function settings()
    {
        if (!is_admin()) {
            access_denied('relatoriospro_settings');
        }
        
        if ($this->input->post()) {
            $enabled = $this->input->post('relatoriospro_enabled') ? '1' : '0';
            update_option('relatoriospro_enabled', $enabled);
            
            set_alert('success', _l('settings_updated'));
            redirect(admin_url('relatoriospro/settings'));
        }
        
        $data['title'] = _l('settings');
        $data['enabled'] = get_option('relatoriospro_enabled', '1');
        
        $this->load->view('partials/settings', $data);
    }
}
