<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro API Controller
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */
class Relatoriospro_api extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('relatoriospro_model');
        $this->load->helper('relatoriospro/relatoriospro');
    }

    /**
     * Extract filters from request with validation
     */
    private function _filters_from_request()
    {
        $filters = [];
        
        // Customer ID validation
        if ($this->input->post('customer_id')) {
            $customer_id = (int)$this->input->post('customer_id');
            if ($customer_id > 0) {
                $filters['customer_id'] = $customer_id;
            }
        }
        
        // Status validation
        if ($this->input->post('status')) {
            $status = $this->input->post('status');
            if (is_numeric($status) || is_array($status)) {
                $filters['status'] = $status;
            }
        }
        
        // Date validation
        if ($this->input->post('date_from')) {
            $date_from = $this->input->post('date_from');
            if (validate_date($date_from)) {
                $filters['date_from'] = $date_from;
            }
        }
        
        if ($this->input->post('date_to')) {
            $date_to = $this->input->post('date_to');
            if (validate_date($date_to)) {
                $filters['date_to'] = $date_to;
            }
        }
        
        // Staff validation
        if ($this->input->post('assigned')) {
            $assigned = (int)$this->input->post('assigned');
            if ($assigned > 0) {
                $filters['assigned'] = $assigned;
            }
        }
        
        // Payment mode validation
        if ($this->input->post('payment_mode')) {
            $payment_mode = (int)$this->input->post('payment_mode');
            if ($payment_mode > 0) {
                $filters['payment_mode'] = $payment_mode;
            }
        }
        
        // Item search validation
        if ($this->input->post('item_search')) {
            $item_search = (int)$this->input->post('item_search');
            if ($item_search > 0) {
                $filters['item_search'] = $item_search;
            }
        }
        
        return $filters;
    }

    /**
     * Get invoices items report
     */
    public function invoices_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) {
            ajax_access_denied();
        }
        
        try {
            $data = $this->relatoriospro_model->documents_items_report('invoice', $this->_filters_from_request());
            relatoriospro_json_ok($data);
        } catch (Exception $e) {
            relatoriospro_json_error('Error loading invoices data: ' . $e->getMessage());
        }
    }

    /**
     * Get estimates items report
     */
    public function estimates_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) {
            ajax_access_denied();
        }
        
        try {
            $data = $this->relatoriospro_model->documents_items_report('estimate', $this->_filters_from_request());
            relatoriospro_json_ok($data);
        } catch (Exception $e) {
            relatoriospro_json_error('Error loading estimates data: ' . $e->getMessage());
        }
    }

    /**
     * Get proposals items report
     */
    public function proposals_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) {
            ajax_access_denied();
        }
        
        try {
            $data = $this->relatoriospro_model->documents_items_report('proposal', $this->_filters_from_request());
            relatoriospro_json_ok($data);
        } catch (Exception $e) {
            relatoriospro_json_error('Error loading proposals data: ' . $e->getMessage());
        }
    }
}
