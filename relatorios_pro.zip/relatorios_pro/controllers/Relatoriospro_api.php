<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Relatoriospro_api extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('relatoriospro_model');
        $this->load->helper('relatoriospro/relatoriospro');
    }

    private function _filters_from_request()
    {
        return [
            'customer_id' => $this->input->post('customer_id') ? (int)$this->input->post('customer_id') : null,
            'status'      => $this->input->post('status') ? $this->input->post('status') : null,
            'date_from'   => $this->input->post('date_from') ? $this->input->post('date_from') : null,
            'date_to'     => $this->input->post('date_to') ? $this->input->post('date_to') : null,
            'assigned'    => $this->input->post('assigned') ? (int)$this->input->post('assigned') : null,
            'payment_mode'=> $this->input->post('payment_mode') ? (int)$this->input->post('payment_mode') : null,
            'item_search' => $this->input->post('item_search') ? $this->input->post('item_search') : null,
        ];
    }

    public function invoices_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) ajax_access_denied();
        $data = $this->relatoriospro_model->documents_items_report('invoice', $this->_filters_from_request());
        relatoriospro_json_ok($data);
    }

    public function estimates_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) ajax_access_denied();
        $data = $this->relatoriospro_model->documents_items_report('estimate', $this->_filters_from_request());
        relatoriospro_json_ok($data);
    }

    public function proposals_items()
    {
        if (!has_permission('relatoriospro', '', 'view')) ajax_access_denied();
        $data = $this->relatoriospro_model->documents_items_report('proposal', $this->_filters_from_request());
        relatoriospro_json_ok($data);
    }
}
