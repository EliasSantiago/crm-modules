<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Relatoriospro_model extends App_Model
{
    public function documents_items_report($type, $filters = [])
    {
        $db = $this->db;
        $prefix = db_prefix();

        $map = [
            'invoice'  => ['table' => $prefix.'invoices',  'status_col' => 'status',  'date_col' => 'date',  'client_col' => 'clientid', 'assigned' => 'sale_agent'],
            'estimate' => ['table' => $prefix.'estimates', 'status_col' => 'status',  'date_col' => 'date',  'client_col' => 'clientid', 'assigned' => 'sale_agent'],
            'proposal' => ['table' => $prefix.'proposals', 'status_col' => 'status',  'date_col' => 'date',  'client_col' => 'rel_id',   'assigned' => 'assigned'],
        ];
        if (!isset($map[$type])) return [];

        $docTable   = $map[$type]['table'];
        $statusCol  = $map[$type]['status_col'];
        $dateCol    = $map[$type]['date_col'];
        $clientCol  = $map[$type]['client_col'];
        $assignedCol= $map[$type]['assigned'];

        $db->select([
            $prefix.'itemable.id as item_id',
            $prefix.'itemable.description as item_description',
            $prefix.'itemable.long_description as item_long_description',
            $prefix.'itemable.qty as qty',
            $prefix.'itemable.rate as rate',
            "({$prefix}itemable.qty * {$prefix}itemable.rate) AS total_item",
            "$docTable.id as doc_id",
            "$docTable.number as doc_number",
            "$docTable.$dateCol as doc_date",
            "$docTable.$statusCol as doc_status",
            $prefix."clients.company as customer",
            $prefix."clients.userid as customer_id",
            "CONCAT({$prefix}staff.firstname, ' ', {$prefix}staff.lastname) as assigned_staff",
            $prefix."staff.staffid as assigned_staff_id"
        ]);
        $db->from($prefix.'itemable');
        $db->join($docTable, "$docTable.id = {$prefix}itemable.rel_id AND {$prefix}itemable.rel_type = ".$db->escape($type), 'inner');
        $db->join($prefix.'clients', "{$prefix}clients.userid = $docTable.$clientCol", 'left');
        $db->join($prefix.'staff', "{$prefix}staff.staffid = $docTable.$assignedCol", 'left');

        if (!empty($filters['customer_id'])) {
            $db->where($prefix.'clients.userid', (int)$filters['customer_id']);
        }
        if (!empty($filters['status'])) {
            $db->where("$docTable.$statusCol", $filters['status']);
        }
        if (!empty($filters['date_from'])) {
            $db->where("$docTable.$dateCol >=", to_sql_date($filters['date_from']));
        }
        if (!empty($filters['date_to'])) {
            $db->where("$docTable.$dateCol <=", to_sql_date($filters['date_to']));
        }
        if (!empty($filters['assigned'])) {
            $db->where("$docTable.$assignedCol", (int)$filters['assigned']);
        }
        if (!empty($filters['payment_mode']) && $type === 'invoice') {
            $db->join($prefix.'invoicepaymentrecords', "{$prefix}invoicepaymentrecords.invoiceid = $docTable.id", 'left');
            $db->where("{$prefix}invoicepaymentrecords.paymentmode", (int)$filters['payment_mode']);
        }
        if (!empty($filters['item_search'])) {
            $like = $filters['item_search'];
            $db->group_start();
            $db->like($prefix.'itemable.description', $like);
            $db->or_like($prefix.'itemable.long_description', $like);
            $db->group_end();
        }

        $db->order_by("$docTable.$dateCol", "DESC");
        return $db->get()->result_array();
    }
}
