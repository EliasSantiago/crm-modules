<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin"><?php echo _l('relatoriospro_estimates_report'); ?></h4>
            <hr class="hr-panel-heading" />
            <?php $this->load->view('relatoriospro/partials/filters'); ?>
            <table id="reportTable" class="table dt-table"></table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>

<script>
(function(){
  var table;
  function fetchData(exportCSV){
    var form = $('#filtersForm');
    var data = form.serializeArray();
    $.post('<?php echo admin_url('relatoriospro_api/estimates_items');?>', data, function(response){
      var rows = response.success ? response.data : [];
      
      if(exportCSV){
        var csv = 'Item,Descrição,Quantidade,Valor,Total,Documento,Número,Data,Status,Cliente,Responsável\n';
        rows.forEach(function(r){
          csv += [
            r.item_id,
            '"'+(r.item_description||'')+'"',
            r.qty,
            r.rate,
            r.total_item,
            r.doc_id,
            r.doc_number||'',
            r.doc_date,
            r.doc_status,
            '"'+(r.customer||'')+'"',
            '"'+(r.assigned_staff||'')+'"'
          ].join(',') + '\n';
        });
        var blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'estimates_report.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return;
      }
      
      if($.fn.DataTable.isDataTable('#reportTable')){
        table.clear().rows.add(rows).draw();
      } else {
        table = $('#reportTable').DataTable({
          data: rows,
          columns: [
            {data:'item_id', title:'ID Item'},
            {data:'item_description', title:'Item'},
            {data:'qty', title:'Qtd'},
            {data:'rate', title:'Valor'},
            {data:'total_item', title:'Total'},
            {data:'doc_id', title:'Doc ID'},
            {data:'doc_number', title:'Número'},
            {data:'doc_date', title:'Data'},
            {data:'doc_status', title:'Status'},
            {data:'customer', title:'Cliente'},
            {data:'assigned_staff', title:'Responsável'}
          ],
          pageLength: 25,
          responsive: true,
          language: {
            "emptyTable": "<?php echo _l('relatoriospro_no_data'); ?>"
          }
        });
      }
    }).fail(function(){
      alert_float('danger', 'Erro ao carregar dados');
    });
  }
  
  $(function(){
    $('#btnSearch').on('click', function(e){ 
      e.preventDefault(); 
      fetchData(false); 
    });
    $('#btnExport').on('click', function(e){ 
      e.preventDefault(); 
      fetchData(true); 
    });
    fetchData(false);
  });
})();
</script>