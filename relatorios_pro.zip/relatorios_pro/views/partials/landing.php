<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin"><?php echo _l('relatoriospro_title'); ?></h4>
            <hr class="hr-panel-heading" />
            <div class="row">
              <div class="col-md-4">
                <div class="panel_s">
                  <div class="panel-body text-center">
                    <h3><i class="fa fa-file-invoice-dollar"></i></h3>
                    <h4><?php echo _l('relatoriospro_invoices_report'); ?></h4>
                    <p>Relatórios detalhados de faturas com análise de itens</p>
                    <a href="<?php echo admin_url('relatoriospro/invoices'); ?>" class="btn btn-primary">
                      <?php echo _l('relatoriospro_invoices_report'); ?>
                    </a>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="panel_s">
                  <div class="panel-body text-center">
                    <h3><i class="fa fa-file-lines"></i></h3>
                    <h4><?php echo _l('relatoriospro_estimates_report'); ?></h4>
                    <p>Relatórios detalhados de orçamentos com análise de itens</p>
                    <a href="<?php echo admin_url('relatoriospro/estimates'); ?>" class="btn btn-primary">
                      <?php echo _l('relatoriospro_estimates_report'); ?>
                    </a>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="panel_s">
                  <div class="panel-body text-center">
                    <h3><i class="fa fa-handshake"></i></h3>
                    <h4><?php echo _l('relatoriospro_proposals_report'); ?></h4>
                    <p>Relatórios detalhados de propostas com análise de itens</p>
                    <a href="<?php echo admin_url('relatoriospro/proposals'); ?>" class="btn btn-primary">
                      <?php echo _l('relatoriospro_proposals_report'); ?>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
