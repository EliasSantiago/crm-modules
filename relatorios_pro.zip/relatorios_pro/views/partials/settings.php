<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin"><?php echo _l('settings'); ?></h4>
            <hr class="hr-panel-heading" />
            <?php echo form_open(admin_url('relatoriospro/settings')); ?>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <div class="checkbox checkbox-primary">
                    <input type="checkbox" id="relatoriospro_enabled" name="relatoriospro_enabled" value="1" <?php echo get_option('relatoriospro_enabled') == '1' ? 'checked' : ''; ?>>
                    <label for="relatoriospro_enabled"><?php echo _l('relatoriospro_enabled_label'); ?></label>
                  </div>
                </div>
              </div>
            </div>
            <div class="btn-bottom-toolbar text-right">
              <button type="submit" class="btn btn-primary"><?php echo _l('save'); ?></button>
            </div>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
