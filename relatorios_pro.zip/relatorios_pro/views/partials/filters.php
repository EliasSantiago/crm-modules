<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="row">
  <div class="col-md-2">
    <?php echo render_date_input('date_from', _l('relatoriospro_date_from')); ?>
  </div>
  <div class="col-md-2">
    <?php echo render_date_input('date_to', _l('relatoriospro_date_to')); ?>
  </div>
  <div class="col-md-3">
    <?php echo render_select('customer_id', $this->clients_model->get(), ['userid', 'company'], _l('relatoriospro_customer')); ?>
  </div>
  <div class="col-md-2">
    <div class="form-group">
      <label for="status"><?php echo _l('relatoriospro_status'); ?></label>
      <input type="text" id="status" name="status" class="form-control" placeholder="e.g. 1,2,3">
    </div>
  </div>
  <div class="col-md-3">
    <?php echo render_select('assigned', $this->staff_model->get(), ['staffid', ['firstname','lastname']], _l('relatoriospro_staff')); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-3 invoices-only">
    <?php echo render_select('payment_mode', $this->payment_modes_model->get(), ['id','name'], _l('relatoriospro_payment_mode')); ?>
  </div>
  <div class="col-md-5">
    <div class="form-group">
      <label for="item_search"><?php echo _l('relatoriospro_item'); ?></label>
      <input type="text" id="item_search" name="item_search" class="form-control" placeholder="Nome/descrição do item">
    </div>
  </div>
  <div class="col-md-4">
    <label>&nbsp;</label>
    <div>
      <button class="btn btn-primary" id="btnSearch"><?php echo _l('relatoriospro_search'); ?></button>
      <button class="btn btn-default" id="btnExport"><?php echo _l('relatoriospro_export_csv'); ?></button>
    </div>
  </div>
</div>
<hr/>
