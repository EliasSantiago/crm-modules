<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php echo form_open('', ['id' => 'filtersForm']); ?>
<div class="row">
  <div class="col-md-2">
    <?php echo render_date_input('date_from', _l('relatoriospro_date_from')); ?>
  </div>
  <div class="col-md-2">
    <?php echo render_date_input('date_to', _l('relatoriospro_date_to')); ?>
  </div>
  <div class="col-md-3">
    <?php echo render_select('customer_id', isset($clients) ? $clients : [], ['userid', 'company'], _l('relatoriospro_customer')); ?>
  </div>
  <div class="col-md-2">
    <div class="form-group">
      <label for="status"><?php echo _l('relatoriospro_status'); ?></label>
      <input type="text" id="status" name="status" class="form-control" placeholder="e.g. 1,2,3">
    </div>
  </div>
  <div class="col-md-3">
    <?php echo render_select('assigned', isset($staff) ? $staff : [], ['staffid', ['firstname','lastname']], _l('relatoriospro_staff')); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-3 invoices-only">
    <?php echo render_select('payment_mode', isset($payment_modes) ? $payment_modes : [], ['id','name'], _l('relatoriospro_payment_mode')); ?>
  </div>
  <div class="col-md-5">
    <?php echo render_select('item_search', isset($items) ? $items : [], ['id', 'description'], _l('relatoriospro_item')); ?>
  </div>
  <div class="col-md-4">
    <label>&nbsp;</label>
    <div>
      <button class="btn btn-primary" id="btnSearch"><?php echo _l('relatoriospro_search'); ?></button>
      <button class="btn btn-default" id="btnExport"><?php echo _l('relatoriospro_export_csv'); ?></button>
    </div>
  </div>
</div>
<hr/>
<?php echo form_close(); ?>
