<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro Module
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */

$CI = &get_instance();

define('RELATORIOSPRO_MODULE', 'relatorios_pro');
define('RELATORIOSPRO_VERSION', '1.1.0');

hooks()->add_action('app_init', 'relatoriospro_register_language_files');
hooks()->add_action('admin_init', 'relatoriospro_init_menu_items');
hooks()->add_filter('module_relatoriospro_action_links', 'relatoriospro_action_links');

function relatoriospro_register_language_files()
{
    register_language_files(RELATORIOSPRO_MODULE, [RELATORIOSPRO_MODULE]);
}

function relatoriospro_init_menu_items()
{
    $CI = &get_instance();
    if (has_permission('relatoriospro', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('relatoriospro', [
            'name'     => _l('relatoriospro_menu'),
            'href'     => admin_url('relatoriospro'),
            'icon'     => 'fa-solid fa-chart-line',
            'position' => 35,
        ]);
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_invoices',
            'name' => _l('relatoriospro_invoices_report'),
            'href' => admin_url('relatoriospro/invoices'),
            'icon' => 'fa-regular fa-file-invoice-dollar',
        ]);
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_estimates',
            'name' => _l('relatoriospro_estimates_report'),
            'href' => admin_url('relatoriospro/estimates'),
            'icon' => 'fa-regular fa-file-lines',
        ]);
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_proposals',
            'name' => _l('relatoriospro_proposals_report'),
            'href' => admin_url('relatoriospro/proposals'),
            'icon' => 'fa-regular fa-handshake',
        ]);
    }

    $capabilities = [
        'capabilities' => [
            'view'   => _l('permission_view') . ' (' . _l('permission_global') . ')',
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
        ],
    ];
    register_staff_capabilities(RELATORIOSPRO_MODULE, $capabilities, _l('relatoriospro'));
}

function relatoriospro_action_links($actions)
{
    $actions[] = '<a href="' . admin_url('relatoriospro/settings') . '">' . _l('settings') . '</a>';
    return $actions;
}
