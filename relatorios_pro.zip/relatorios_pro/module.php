<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro Module Entry Point
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */

// Load module configuration
require_once(__DIR__ . '/config.php');
