<?php
defined('BASEPATH') or exit('No direct script access allowed');

$lang['relatoriospro'] = 'Relatórios Pro';
$lang['relatoriospro_menu'] = 'Relatórios Pro';
$lang['relatoriospro_title'] = 'Relatórios e Dashboards';
$lang['relatoriospro_invoices_report'] = 'Relatório de Faturas';
$lang['relatoriospro_estimates_report'] = 'Relatório de Orçamentos';
$lang['relatoriospro_proposals_report'] = 'Relatório de Propostas';
$lang['relatoriospro_enabled_label'] = 'Habilitar Relatórios Pro';
$lang['relatoriospro_filters'] = 'Filtros';
$lang['relatoriospro_customer'] = 'Cliente';
$lang['relatoriospro_status'] = 'Status';
$lang['relatoriospro_date_from'] = 'Data inicial';
$lang['relatoriospro_date_to'] = 'Data final';
$lang['relatoriospro_staff'] = 'Responsável';
$lang['relatoriospro_payment_mode'] = 'Forma de pagamento';
$lang['relatoriospro_item'] = 'Item';
$lang['relatoriospro_export_csv'] = 'Exportar CSV';
$lang['relatoriospro_search'] = 'Buscar';
$lang['relatoriospro_no_data'] = 'Nenhum dado encontrado';
$lang['relatoriospro_total_items'] = 'Total de Itens';
$lang['relatoriospro_total_value'] = 'Valor Total';
$lang['relatoriospro_document_number'] = 'Número do Documento';
$lang['relatoriospro_assigned_staff'] = 'Responsável';
