<?php
defined('BASEPATH') or exit('No direct script access allowed');

$version = get_option('relatoriospro_version');
if (!$version) {
    add_option('relatoriospro_version', RELATORIOSPRO_VERSION);
    $version = RELATORIOSPRO_VERSION;
}
if (version_compare($version, '1.1.0', '<')) {
    update_option('relatoriospro_version', '1.1.0');
}
