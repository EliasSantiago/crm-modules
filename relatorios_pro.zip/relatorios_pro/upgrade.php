<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro Module Upgrade Script
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */

$version = get_option('relatoriospro_version');

if (!$version) {
    add_option('relatoriospro_version', RELATORIOSPRO_VERSION);
    add_option('relatoriospro_enabled', '1');
    $version = RELATORIOSPRO_VERSION;
}

// Upgrade to version 1.1.0
if (version_compare($version, '1.1.0', '<')) {
    update_option('relatoriospro_version', '1.1.0');
    
    // Add any new options or database changes here
    if (!get_option('relatoriospro_enabled')) {
        add_option('relatoriospro_enabled', '1');
    }
}
