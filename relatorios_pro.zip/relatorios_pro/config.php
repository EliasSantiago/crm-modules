<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Relatorios Pro Module Configuration
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */

// Module constants
define('RELATORIOSPRO_MODULE', 'relatorios_pro');
define('RELATORIOSPRO_VERSION', '1.1.0');
define('RELATORIOSPRO_PATH', module_dir_path(RELATORIOSPRO_MODULE));

// Load helper
$CI = &get_instance();
$CI->load->helper('relatoriospro/relatoriospro');

// Register hooks
hooks()->add_action('app_init', 'relatoriospro_register_language_files');
hooks()->add_action('admin_init', 'relatoriospro_init_menu_items');
hooks()->add_filter('module_relatoriospro_action_links', 'relatoriospro_action_links');

/**
 * Register language files
 */
function relatoriospro_register_language_files()
{
    register_language_files(RELATORIOSPRO_MODULE, [RELATORIOSPRO_MODULE]);
}

/**
 * Initialize menu items
 */
function relatoriospro_init_menu_items()
{
    $CI = &get_instance();
    
    if (has_permission('relatoriospro', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('relatoriospro', [
            'name'     => _l('relatoriospro_menu'),
            'href'     => admin_url('relatoriospro'),
            'icon'     => 'fa fa-chart-line',
            'position' => 35,
        ]);
        
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_invoices',
            'name' => _l('relatoriospro_invoices_report'),
            'href' => admin_url('relatoriospro/invoices'),
            'icon' => 'fa fa-file-invoice-dollar',
        ]);
        
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_estimates',
            'name' => _l('relatoriospro_estimates_report'),
            'href' => admin_url('relatoriospro/estimates'),
            'icon' => 'fa fa-file-lines',
        ]);
        
        $CI->app_menu->add_sidebar_children_item('relatoriospro', [
            'slug' => 'relatoriospro_proposals',
            'name' => _l('relatoriospro_proposals_report'),
            'href' => admin_url('relatoriospro/proposals'),
            'icon' => 'fa fa-handshake',
        ]);
    }

    // Register staff capabilities
    $capabilities = [
        'capabilities' => [
            'view'   => _l('permission_view') . ' (' . _l('permission_global') . ')',
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
        ],
    ];
    register_staff_capabilities(RELATORIOSPRO_MODULE, $capabilities, _l('relatoriospro'));
}

/**
 * Add action links to module
 */
function relatoriospro_action_links($actions)
{
    $actions[] = '<a href="' . admin_url('relatoriospro/settings') . '">' . _l('settings') . '</a>';
    return $actions;
}

/**
 * Add quick access to top menu
 */
function relatoriospro_add_top_menu()
{
    if (!relatoriospro_can('view')) {
        return;
    }
    
    $CI = &get_instance();
    
    // Add to top menu
    $CI->app_menu->add_quick_link('relatoriospro', [
        'name' => _l('relatoriospro_menu'),
        'href' => admin_url('relatoriospro'),
        'icon' => 'fa fa-chart-line',
        'position' => 10,
    ]);
}

// Register top menu
hooks()->add_action('admin_init', 'relatoriospro_add_top_menu');
