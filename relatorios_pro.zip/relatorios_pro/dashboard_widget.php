<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Add Relatorios Pro widget to dashboard
 */
function relatoriospro_dashboard_widget()
{
    if (!relatoriospro_can('view')) {
        return;
    }
    
    $CI = &get_instance();
    
    // Get quick stats
    $total_invoices = $CI->db->count_all_results(db_prefix() . 'invoices');
    $total_estimates = $CI->db->count_all_results(db_prefix() . 'estimates');
    $total_proposals = $CI->db->count_all_results(db_prefix() . 'proposals');
    
    echo '<div class="col-md-4 col-sm-6 col-xs-12">
        <div class="panel_s">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-8">
                        <h4 class="no-margin">' . _l('relatoriospro_menu') . '</h4>
                        <p class="text-muted">Acesso rápido aos relatórios</p>
                    </div>
                    <div class="col-md-4 text-right">
                        <i class="fa fa-chart-line fa-2x text-primary"></i>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4 text-center">
                        <a href="' . admin_url('relatoriospro/invoices') . '" class="btn btn-primary btn-sm">
                            <i class="fa fa-file-invoice-dollar"></i><br>
                            <small>Faturas</small>
                        </a>
                    </div>
                    <div class="col-md-4 text-center">
                        <a href="' . admin_url('relatoriospro/estimates') . '" class="btn btn-info btn-sm">
                            <i class="fa fa-file-lines"></i><br>
                            <small>Orçamentos</small>
                        </a>
                    </div>
                    <div class="col-md-4 text-center">
                        <a href="' . admin_url('relatoriospro/proposals') . '" class="btn btn-success btn-sm">
                            <i class="fa fa-handshake"></i><br>
                            <small>Propostas</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>';
}

// Register dashboard widget
hooks()->add_action('dashboard_widgets', 'relatoriospro_dashboard_widget');
