<?php
defined('BASEPATH') or exit('No direct script access allowed');

delete_option('relatoriospro_enabled');
delete_option('relatoriospro_version');
