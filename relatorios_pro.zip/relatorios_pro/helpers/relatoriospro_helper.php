<?php
defined('BASEPATH') or exit('No direct script access allowed');

// @phpstan-ignore-file - Perfex CRM functions not recognized by static analysis

/**
 * Relatorios Pro Helper Functions
 * 
 * @package     PerfexCRM
 * @subpackage  Modules
 * @category    Reports
 * @author      DTL Group Solutions
 * @link        https://dtlgroupsolutions.com
 * @version     1.1.0
 */

/**
 * Check if user has permission for relatoriospro
 */
function relatoriospro_can($action = 'view') {
    return has_permission('relatoriospro', '', $action);
}

/**
 * Return JSON success response
 */
function relatoriospro_json_ok($data) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'data' => $data
    ]);
    die;
}

/**
 * Return JSON error response
 */
function relatoriospro_json_error($message) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => $message
    ]);
    die;
}

/**
 * Format currency amount
 */
function relatoriospro_format_currency($amount) {
    return app_format_money($amount, get_base_currency());
}

/**
 * Format date
 */
function relatoriospro_format_date($date) {
    return _d($date);
}

/**
 * Get status label for different document types
 */
function relatoriospro_get_status_label($status, $type = 'invoice') {
    $statuses = [
        'invoice' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Paid',
            5 => 'Overdue',
            6 => 'Cancelled'
        ],
        'estimate' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Accepted',
            5 => 'Declined',
            6 => 'Expired'
        ],
        'proposal' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Accepted',
            5 => 'Declined',
            6 => 'Expired'
        ]
    ];
    
    return isset($statuses[$type][$status]) ? $statuses[$type][$status] : 'Unknown';
}

/**
 * Validate date format
 */
function validate_date($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}
