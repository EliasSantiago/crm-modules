<?php
defined('BASEPATH') or exit('No direct script access allowed');

function relatoriospro_can($action = 'view') {
    return has_permission('relatoriospro', '', $action);
}

function relatoriospro_json_ok($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    die;
}

function relatoriospro_format_currency($amount) {
    return app_format_money($amount, get_base_currency());
}

function relatoriospro_format_date($date) {
    return _d($date);
}

function relatoriospro_get_status_label($status, $type = 'invoice') {
    $statuses = [
        'invoice' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Paid',
            5 => 'Overdue',
            6 => 'Cancelled'
        ],
        'estimate' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Accepted',
            5 => 'Declined',
            6 => 'Expired'
        ],
        'proposal' => [
            1 => 'Draft',
            2 => 'Sent',
            3 => 'Viewed',
            4 => 'Accepted',
            5 => 'Declined',
            6 => 'Expired'
        ]
    ];
    
    return isset($statuses[$type][$status]) ? $statuses[$type][$status] : 'Unknown';
}
