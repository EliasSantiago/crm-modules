<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module Information
 */
return [
    'name' => 'Relatorios Pro',
    'description' => 'Advanced reports module for detailed analysis of items in invoices, estimates and proposals',
    'version' => '1.1.0',
    'author' => 'DTL Group Solutions',
    'author_url' => 'https://dtlgroupsolutions.com',
    'website' => 'https://dtlgroupsolutions.com',
    'category' => 'reports',
    'slug' => 'relatorios_pro',
    'dependencies' => [],
    'perfex_version' => '3.2.0',
    'php_version' => '7.4',
    'database_version' => '1.0.0',
    'install_sql' => false,
    'uninstall_sql' => false,
    'upgrade_sql' => false,
];
