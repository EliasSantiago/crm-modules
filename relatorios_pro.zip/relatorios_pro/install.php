<?php
defined('BASEPATH') or exit('No direct script access allowed');

add_option('relatoriospro_enabled', '1');
add_option('relatoriospro_version', RELATORIOSPRO_VERSION);
