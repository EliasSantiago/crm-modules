# Relatórios Pro - Módulo para Perfex CRM

## Descrição
Módulo avançado de relatórios para Perfex CRM que permite análise detalhada de itens em faturas, orçamentos e propostas.

## Funcionalidades

### Relatórios Disponíveis
- **Relatório de Faturas**: Análise detalhada de itens em faturas
- **Relatório de Orçamentos**: Análise detalhada de itens em orçamentos  
- **Relatório de Propostas**: Análise detalhada de itens em propostas

### Filtros Avançados
- Filtro por cliente
- Filtro por status do documento
- Filtro por período (data inicial e final)
- Filtro por responsável/vendedor
- Filtro por forma de pagamento (apenas faturas)
- Busca por nome/descrição do item

### Recursos
- Exportação para CSV
- Interface responsiva
- Permissões de acesso configuráveis
- Suporte completo ao português brasileiro

## Instalação

1. Faça upload da pasta `relatorios_pro` para o diretório `modules/` do seu Perfex CRM
2. Acesse o painel administrativo do Perfex CRM
3. Vá em **Setup > Modules** e ative o módulo "Relatórios Pro"
4. Configure as permissões conforme necessário

## Permissões

O módulo utiliza o sistema de permissões do Perfex CRM:
- **View**: Visualizar relatórios
- **Create**: Criar novos relatórios (futuro)
- **Edit**: Editar configurações
- **Delete**: Excluir dados (futuro)

## Estrutura do Módulo

```
relatorios_pro/
├── config.php              # Configuração principal do módulo
├── install.php             # Script de instalação
├── uninstall.php           # Script de desinstalação
├── upgrade.php             # Script de atualização
├── controllers/
│   ├── Relatoriospro.php   # Controller principal
│   └── Relatoriospro_api.php # Controller da API
├── models/
│   └── Relatoriospro_model.php # Modelo de dados
├── views/
│   ├── invoices/index.php  # View do relatório de faturas
│   ├── estimates/index.php # View do relatório de orçamentos
│   ├── proposals/index.php # View do relatório de propostas
│   └── partials/
│       ├── filters.php      # Filtros reutilizáveis
│       ├── landing.php      # Página inicial
│       └── settings.php     # Configurações
├── helpers/
│   └── relatoriospro_helper.php # Funções auxiliares
└── language/
    └── portuguese/
        └── relatoriospro_lang.php # Traduções em português
```

## Uso

1. Acesse **Relatórios Pro** no menu lateral
2. Escolha o tipo de relatório desejado
3. Configure os filtros conforme necessário
4. Clique em "Buscar" para gerar o relatório
5. Use "Exportar CSV" para baixar os dados

## Requisitos

- **Perfex CRM**: versão 3.2.0 ou superior
- **PHP**: 7.4 ou superior
- **MySQL**: 5.7 ou superior

## Suporte

Para suporte técnico ou dúvidas sobre o módulo, entre em contato através dos canais oficiais do Perfex CRM.

## Changelog

### Versão 1.1.0
- Correção de bugs no modelo de dados
- Melhoria na segurança das validações
- Adição de informações do responsável nos relatórios
- Melhoria na interface de usuário
- Correção de problemas de formatação

### Versão 1.0.0
- Versão inicial do módulo
- Relatórios básicos de faturas, orçamentos e propostas
- Sistema de filtros
- Exportação CSV
