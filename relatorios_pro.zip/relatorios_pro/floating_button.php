<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Add floating action button for quick access
 */
function relatoriospro_floating_button()
{
    if (!relatoriospro_can('view')) {
        return;
    }
    
    echo '<div id="relatoriospro-fab" class="fab-container">
        <div class="fab-main">
            <i class="fa fa-chart-line"></i>
        </div>
        <div class="fab-menu">
            <a href="' . admin_url('relatoriospro/invoices') . '" class="fab-item" title="Relatório de Faturas">
                <i class="fa fa-file-invoice-dollar"></i>
            </a>
            <a href="' . admin_url('relatoriospro/estimates') . '" class="fab-item" title="Relatório de Orçamentos">
                <i class="fa fa-file-lines"></i>
            </a>
            <a href="' . admin_url('relatoriospro/proposals') . '" class="fab-item" title="Relatório de Propostas">
                <i class="fa fa-handshake"></i>
            </a>
        </div>
    </div>';
    
    echo '<style>
    .fab-container {
        position: fixed;
        bottom: 30px;
        right: 30px;
        z-index: 1000;
    }
    .fab-main {
        width: 60px;
        height: 60px;
        background: #007bff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,123,255,0.3);
        transition: all 0.3s ease;
    }
    .fab-main:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 16px rgba(0,123,255,0.4);
    }
    .fab-menu {
        position: absolute;
        bottom: 70px;
        right: 0;
        display: none;
        flex-direction: column;
        gap: 10px;
    }
    .fab-item {
        width: 50px;
        height: 50px;
        background: #28a745;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        text-decoration: none;
        font-size: 18px;
        box-shadow: 0 2px 8px rgba(40,167,69,0.3);
        transition: all 0.3s ease;
    }
    .fab-item:hover {
        transform: scale(1.1);
        color: white;
        text-decoration: none;
    }
    .fab-container:hover .fab-menu {
        display: flex;
    }
    </style>';
    
    echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        const fab = document.getElementById("relatoriospro-fab");
        if (fab) {
            fab.addEventListener("click", function(e) {
                e.preventDefault();
                const menu = fab.querySelector(".fab-menu");
                menu.style.display = menu.style.display === "flex" ? "none" : "flex";
            });
        }
    });
    </script>';
}

// Add to all admin pages
hooks()->add_action('admin_footer', 'relatoriospro_floating_button');
