<?php
defined('BASEPATH') or exit('No direct script access allowed');

function relatoriospro_can($action = 'view') {
    return has_permission('relatoriospro', '', $action);
}

function relatoriospro_json_ok($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    die;
}
