<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div class="panel_s">
  <div class="panel-body">
    <h4 class="no-margin">Relatório de Itens por Cliente</h4>
    <hr class="mt-2 mb-4" />
    
    <form method="get" class="mbot15">
      <div class="row">
        <div class="col-md-2">
          <?php echo render_date_input('from','De', $filters['from']); ?>
        </div>
        <div class="col-md-2">
          <?php echo render_date_input('to','Até', $filters['to']); ?>
        </div>
        <div class="col-md-3">
          <div class="form-group">
            <label for="agent_id" class="control-label">Agente de Venda</label>
            <select id="agent_id" name="agent_id" class="selectpicker" data-width="100%" data-none-selected-text="Todos">
              <option value=""></option>
              <?php foreach($agents as $a): ?>
                <option value="<?php echo $a['staffid']; ?>" <?php echo ($filters['agent_id']==$a['staffid'] ? 'selected' : ''); ?>>
                  <?php echo $a['name']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group">
            <label for="status" class="control-label">Status da Fatura</label>
            <select id="status" name="status" class="selectpicker" data-width="100%">
              <option value="">Todos</option>
              <option value="2" <?php echo ($filters['status']=='2'?'selected':''); ?>>Pagas</option>
              <option value="1" <?php echo ($filters['status']=='1'?'selected':''); ?>>Não Pagas</option>
              <option value="3" <?php echo ($filters['status']=='3'?'selected':''); ?>>Parcial</option>
              <option value="4" <?php echo ($filters['status']=='4'?'selected':''); ?>>Vencidas</option>
            </select>
          </div>
        </div>
        <div class="col-md-3">
          <?php echo render_input('search','Procurar', $filters['search']); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <button type="submit" class="btn btn-primary">Aplicar</button>
          <a href="<?php echo admin_url('reports/sales?report=relatorio_itens_por_cliente'); ?>" class="btn btn-default">Limpar</a>
          <a href="<?php echo admin_url('relatorioitensclientes/export?'.http_build_query($filters)); ?>" class="btn btn-success pull-right">
            <i class="fa fa-download"></i> Exportar CSV
          </a>
        </div>
      </div>
    </form>

    <div class="clearfix"></div>
    <table class="table dt-table table-striped">
      <thead>
        <tr>
          <th>Item</th>
          <th>Cliente</th>
          <th>Fatura</th>
          <th>Data</th>
          <th>Quantidade</th>
          <th>Preço Unitário</th>
          <th>Valor Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr>
            <td><?php echo $r['item']; ?></td>
            <td><?php echo $r['cliente']; ?></td>
            <td><a href="<?php echo admin_url('invoices/list_invoices/'.$r['invoice_id']); ?>" target="_blank">
              <?php echo format_invoice_number($r['invoice_id']); ?>
            </a></td>
            <td><?php echo _d($r['invoice_date']); ?></td>
            <td><?php echo $r['quantidade']; ?></td>
            <td><?php echo $r['preco_unitario']; ?></td>
            <td><?php echo $r['valor_total']; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
