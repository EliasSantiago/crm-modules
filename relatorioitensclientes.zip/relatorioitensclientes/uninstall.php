<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module uninstallation file
 * This file is executed when the module is uninstalled
 */
function relatorioitensclientes_uninstall()
{
    // Module uninstallation logic can be added here if needed
    // For this module, no database cleanup is required
    // as it doesn't create any custom tables
    
    return true;
}