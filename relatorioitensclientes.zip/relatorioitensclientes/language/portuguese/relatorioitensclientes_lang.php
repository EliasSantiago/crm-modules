<?php
defined('BASEPATH') or exit('No direct script access allowed');

$lang['Relatório de Itens por Cliente'] = 'Relatório de Itens por Cliente';
$lang['De'] = 'De';
$lang['Até'] = 'Até';
$lang['Agente de Venda'] = 'Agente de Venda';
$lang['Status da Fatura'] = 'Status da Fatura';
$lang['Procurar'] = 'Procurar';
$lang['Todos'] = 'Todos';
$lang['Pagas'] = 'Pagas';
$lang['Não Pagas'] = 'Não Pagas';
$lang['Parcial'] = 'Parcial';
$lang['Vencidas'] = 'Vencidas';
$lang['Aplicar'] = 'Aplicar';
$lang['Limpar'] = 'Limpar';
$lang['Exportar CSV'] = 'Exportar CSV';
$lang['Item'] = 'Item';
$lang['Cliente'] = 'Cliente';
$lang['Fatura'] = 'Fatura';
$lang['Data'] = 'Data';
$lang['Quantidade'] = 'Quantidade';
$lang['Preço Unitário'] = 'Preço Unitário';
$lang['Valor Total'] = 'Valor Total';