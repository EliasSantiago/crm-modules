# Relatório de Itens por Cliente

**Versão:** 1.0.1  
**Autor:** Desenvolvedor  
**Categoria:** Reports  
**Compatibilidade:** Perfex CRM  

## Descrição

Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.

## Funcionalidades

- Relatório de itens vendidos por cliente
- Filtros por período (data de/até)
- Filtro por agente de venda
- Filtro por status da fatura (Paga, Não Paga, Parcial, Vencida)
- Busca por item ou cliente
- Exportação para CSV
- Interface responsiva integrada ao Perfex CRM

## Instalação

1. Faça upload do módulo através do painel administrativo
2. Ative o módulo em Configurações > Módulos
3. Acesse Reports > Relatório de Itens por Cliente

## Permissões

- Requer permissão para visualizar relatórios (`reports` > `view`)

## Estrutura do Módulo

```
relatorioitensclientes/
├── relatorioitensclientes.php    # Arquivo principal
├── config.php                    # Configurações do módulo
├── module_info.php              # Informações do módulo
├── install.php                  # Instalação
├── uninstall.php                # Desinstalação
├── upgrade.php                  # Atualização
├── hooks.php                    # Hooks adicionais
├── controllers/
│   └── Relatorioitensclientes.php
├── models/
│   └── Relatorioitensclientes_model.php
├── views/
│   └── relatorioitensclientes/
│       └── index.php
└── language/
    └── portuguese/
        └── relatorioitensclientes_lang.php
```
