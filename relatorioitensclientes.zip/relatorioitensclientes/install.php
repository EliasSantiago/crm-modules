<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module installation file
 * This file is executed when the module is installed
 */
function relatorioitensclientes_install()
{
    // Module installation logic can be added here if needed
    // For this module, no database tables need to be created
    // as it uses existing Perfex CRM tables
    
    return true;
}