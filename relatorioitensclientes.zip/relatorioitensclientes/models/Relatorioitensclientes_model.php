<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Relatorioitensclientes_model extends App_Model
{
    public function get_sale_agents()
    {
        return $this->db->select('staffid, CONCAT(firstname, " ", lastname) as name', false)
            ->where('active', 1)
            ->get(db_prefix().'staff')
            ->result_array();
    }

    public function get_itens_vendidos($filters = [])
    {
        $from = isset($filters['from']) && $filters['from'] ? to_sql_date($filters['from']) : null;
        $to   = isset($filters['to']) && $filters['to'] ? to_sql_date($filters['to']) : null;
        $agent_id = isset($filters['agent_id']) && $filters['agent_id'] !== '' ? (int)$filters['agent_id'] : null;
        $status   = isset($filters['status']) && $filters['status'] !== '' ? (int)$filters['status'] : null;
        $search   = isset($filters['search']) ? trim($filters['search']) : '';

        $this->db->select('
            ii.description as item,
            c.company as cliente,
            inv.id as invoice_id,
            inv.date as invoice_date,
            ii.qty as quantidade,
            ii.rate as preco_unitario,
            (ii.qty * ii.rate) as valor_total
        ', false);
        $this->db->from(db_prefix().'itemable as ii');
        $this->db->join(db_prefix().'invoices as inv', "inv.id = ii.rel_id AND ii.rel_type = 'invoice'", 'inner');
        $this->db->join(db_prefix().'clients as c', 'c.userid = inv.clientid', 'inner');

        if (!is_null($status)) {
            $this->db->where('inv.status', $status);
        }
        if ($from) {
            $this->db->where('inv.date >=', $from);
        }
        if ($to) {
            $this->db->where('inv.date <=', $to);
        }
        if (!is_null($agent_id)) {
            $this->db->where('inv.sale_agent', $agent_id);
        }
        if ($search !== '') {
            $this->db->group_start();
            $this->db->like('ii.description', $search);
            $this->db->or_like('c.company', $search);
            $this->db->group_end();
        }

        $this->db->order_by('ii.description ASC, c.company ASC, inv.date DESC');
        $res = $this->db->get()->result_array();

        foreach ($res as &$r) {
            $r['preco_unitario'] = app_format_money($r['preco_unitario'], get_base_currency());
            $r['valor_total']    = app_format_money($r['valor_total'], get_base_currency());
        }
        return $res;
    }
}
