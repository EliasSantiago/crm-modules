<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module Configuration File
 * This file contains the module metadata for Perfex CRM
 */

return [
    'name' => 'Relatório de Itens por Cliente',
    'description' => 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.',
    'version' => '1.0.1',
    'author' => 'Desenvolvedor',
    'website' => '',
    'email' => '',
    'category' => 'reports',
    'dependencies' => [],
    'permissions' => [
        'reports' => ['view']
    ],
    'hooks' => [
        'admin_init' => 'relatorioitensclientes_init_menu_items'
    ]
];
