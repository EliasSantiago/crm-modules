<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module upgrade file
 * This file is executed when the module is upgraded
 */
function relatorioitensclientes_upgrade()
{
    // Module upgrade logic can be added here if needed
    // For this module, no database changes are required for upgrades
    
    return true;
}