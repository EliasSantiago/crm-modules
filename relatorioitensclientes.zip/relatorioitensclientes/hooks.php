<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module hooks file
 * This file contains additional hooks for the module
 */

// Additional hooks can be added here if needed
// For example, hooks to modify other parts of the system
// or to add functionality to other modules

// Example hook to add custom CSS/JS (uncomment if needed):
/*
hooks()->add_action('app_admin_head', 'relatorioitensclientes_admin_head');
function relatorioitensclientes_admin_head()
{
    // Add custom CSS or JS here
}
*/