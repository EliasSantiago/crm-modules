<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Relatorioitensclientes extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('relatorioitensclientes_model');
    }

    public function index()
    {
        $filters = [];
        $filters['from'] = $this->input->get('from') ?: '';
        $filters['to']   = $this->input->get('to') ?: '';
        $filters['agent_id'] = $this->input->get('agent_id') ?: '';
        $filters['status']   = $this->input->get('status') ?: '2';
        $filters['search']   = $this->input->get('search') ?: '';

        $data['title']   = 'Relatório de Itens por Cliente';
        $data['filters'] = $filters;
        $data['agents']  = $this->relatorioitensclientes_model->get_sale_agents();
        $data['rows']    = $this->relatorioitensclientes_model->get_itens_vendidos($filters);
        $this->load->view('relatorioitensclientes/index', $data);
    }

    // Método para ser chamado dentro da página de relatórios de vendas
    public function sales_report()
    {
        if (!has_permission('reports', '', 'view')) {
            access_denied('Relatório de Itens por Cliente');
        }

        $filters = [];
        $filters['from'] = $this->input->get('from') ?: '';
        $filters['to']   = $this->input->get('to') ?: '';
        $filters['agent_id'] = $this->input->get('agent_id') ?: '';
        $filters['status']   = $this->input->get('status') ?: '';
        $filters['search']   = $this->input->get('search') ?: '';

        $data['filters'] = $filters;
        $data['agents']  = $this->relatorioitensclientes_model->get_sale_agents();
        $data['rows']    = $this->relatorioitensclientes_model->get_itens_vendidos($filters);
        
        // Retorna apenas o conteúdo do relatório para ser inserido na página de relatórios
        $this->load->view('relatorioitensclientes/sales_report_content', $data);
    }

    public function export()
    {
        if (!has_permission('reports', '', 'view')) {
            access_denied('Relatório de Itens por Cliente');
        }
        $filters = $this->input->get();
        $rows = $this->relatorioitensclientes_model->get_itens_vendidos($filters);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=relatorio_itens_por_cliente.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Item','Cliente','Fatura','Data Fatura','Quantidade','Preço Unitário','Valor Total']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['item'],
                $r['cliente'],
                format_invoice_number($r['invoice_id']),
                _d($r['invoice_date']),
                $r['quantidade'],
                strip_tags($r['preco_unitario']),
                strip_tags($r['valor_total']),
            ]);
        }
        fclose($out);
        exit;
    }
}