<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module Information File
 * Contains module metadata for Perfex CRM module manager
 */

// Module Information
$module_info = [
    'name' => 'Relatório de Itens por Cliente',
    'description' => 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.',
    'version' => '1.0.1',
    'author' => 'Desenvolvedor',
    'website' => '',
    'email' => '',
    'category' => 'reports',
    'dependencies' => [],
    'permissions' => [
        'reports' => ['view']
    ]
];

// Export module info
return $module_info;
