<?php
/**
 * Relatório de Itens por Cliente
 * 
 * @package     Perfex CRM
 * @subpackage  Modules
 * @category    Reports
 * @author      Desenvolvedor
 * @version     1.0.1
 * @description Módulo para gerar relatórios detalhados de itens vendidos por cliente, 
 *              com filtros por data, agente de venda e status da fatura.
 */

defined('BASEPATH') or exit('No direct script access allowed');

define('RELATORIOITENSCLIENTES_MODULE', 'relatorioitensclientes');
define('RELATORIOITENSCLIENTES_MODULE_NAME', 'Relatório de Itens por Cliente');
define('RELATORIOITENSCLIENTES_MODULE_DESCRIPTION', 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.');
define('RELATORIOITENSCLIENTES_MODULE_VERSION', '1.0.1');

// Module metadata for Perfex CRM
$module_name = 'Relatório de Itens por Cliente';
$module_description = 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.';
$module_version = '1.0.1';

// Hook para adicionar o relatório na página de relatórios de vendas
hooks()->add_action('app_admin_head', 'relatorioitensclientes_add_report_link');

function relatorioitensclientes_add_report_link()
{
    $CI = &get_instance();
    $current_url = $CI->uri->uri_string();
    
    // Verifica se estamos na página de relatórios de vendas
    if (strpos($current_url, 'reports/sales') !== false && has_permission('reports', '', 'view')) {
        echo '<script>
        $(document).ready(function() {
            // Adiciona o link do relatório na lista de relatórios
            var reportLink = $("<a href=\"" + "' . admin_url('reports/sales?report=relatorio_itens_por_cliente') . '" + "\" class=\"list-group-item\"><i class=\"fa fa-list-alt\"></i> Relatório de Itens por Cliente</a>");
            
            // Procura pela lista de relatórios e adiciona o novo item
            if ($(".list-group").length > 0) {
                $(".list-group").first().append(reportLink);
            } else {
                // Se não encontrar a lista, cria uma estrutura básica
                var listGroup = $("<div class=\"list-group\"></div>");
                listGroup.append(reportLink);
                $(".panel_s .panel-body").first().prepend(listGroup);
            }
            
            // Verifica se o parâmetro report está presente e carrega o conteúdo
            var urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get("report") === "relatorio_itens_por_cliente") {
                // Carrega o conteúdo do relatório via AJAX
                $.get("' . admin_url('relatorioitensclientes/sales_report') . '", function(data) {
                    $("#sales-reports-content").html(data);
                });
            }
        });
        </script>';
    }
}

// Hook para interceptar o carregamento do relatório
hooks()->add_action('before_render_sales_reports_content', 'relatorioitensclientes_load_report_content');

function relatorioitensclientes_load_report_content()
{
    $CI = &get_instance();
    $report = $CI->input->get('report');
    
    if ($report === 'relatorio_itens_por_cliente' && has_permission('reports', '', 'view')) {
        // Carrega o conteúdo do nosso relatório
        $CI->load->model('relatorioitensclientes_model');
        
        $filters = [];
        $filters['from'] = $CI->input->get('from') ?: '';
        $filters['to']   = $CI->input->get('to') ?: '';
        $filters['agent_id'] = $CI->input->get('agent_id') ?: '';
        $filters['status']   = $CI->input->get('status') ?: '';
        $filters['search']   = $CI->input->get('search') ?: '';

        $data['filters'] = $filters;
        $data['agents']  = $CI->relatorioitensclientes_model->get_sale_agents();
        $data['rows']    = $CI->relatorioitensclientes_model->get_itens_vendidos($filters);
        
        $CI->load->view('relatorioitensclientes/sales_report_content', $data);
        return true; // Impede o carregamento do conteúdo padrão
    }
    
    return false;
}

// Module information functions
function relatorioitensclientes_module_name()
{
    return RELATORIOITENSCLIENTES_MODULE_NAME;
}

function relatorioitensclientes_module_description()
{
    return RELATORIOITENSCLIENTES_MODULE_DESCRIPTION;
}

function relatorioitensclientes_module_version()
{
    return RELATORIOITENSCLIENTES_MODULE_VERSION;
}

// Optional activation hook (keeps compatibility)
register_activation_hook(RELATORIOITENSCLIENTES_MODULE, 'relatorioitensclientes_activation_hook');
function relatorioitensclientes_activation_hook() {
    // nothing to run on activation
}
