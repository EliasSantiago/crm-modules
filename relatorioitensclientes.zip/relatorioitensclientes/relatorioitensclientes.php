<?php
defined('BASEPATH') or exit('No direct script access allowed');

define('RELATORIOITENSCLIENTES_MODULE', 'relatorioitensclientes');

hooks()->add_action('admin_init', 'relatorioitensclientes_init_menu_items');

function relatorioitensclientes_init_menu_items()
{
    $CI = &get_instance();
    if (has_permission('reports', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('relatorio_itens_por_cliente', [
            'slug'     => 'relatorioitensclientes',
            'name'     => _l('Relatório de Itens por Cliente'),
            'icon'     => 'fa fa-list-alt',
            'href'     => admin_url('relatorioitensclientes'),
            'position' => 6,
            'parent'   => 'reports',
        ]);
    }
}

// Optional activation hook (keeps compatibility)
register_activation_hook(RELATORIOITENSCLIENTES_MODULE, 'relatorioitensclientes_activation_hook');
function relatorioitensclientes_activation_hook() {
    // nothing to run on activation
}
