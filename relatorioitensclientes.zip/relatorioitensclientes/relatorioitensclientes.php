<?php
/**
 * Relatório de Itens por Cliente
 * 
 * @package     Perfex CRM
 * @subpackage  Modules
 * @category    Reports
 * @author      Desenvolvedor
 * @version     1.0.1
 * @description Módulo para gerar relatórios detalhados de itens vendidos por cliente, 
 *              com filtros por data, agente de venda e status da fatura.
 */

defined('BASEPATH') or exit('No direct script access allowed');

define('RELATORIOITENSCLIENTES_MODULE', 'relatorioitensclientes');
define('RELATORIOITENSCLIENTES_MODULE_NAME', 'Relatório de Itens por Cliente');
define('RELATORIOITENSCLIENTES_MODULE_DESCRIPTION', 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.');
define('RELATORIOITENSCLIENTES_MODULE_VERSION', '1.0.1');

// Module metadata for Perfex CRM
$module_name = 'Relatório de Itens por Cliente';
$module_description = 'Módulo para gerar relatórios detalhados de itens vendidos por cliente, com filtros por data, agente de venda e status da fatura.';
$module_version = '1.0.1';

// Hook principal para adicionar o relatório na página de relatórios de vendas
hooks()->add_action('app_admin_init', 'relatorioitensclientes_init');

function relatorioitensclientes_init()
{
    $CI = &get_instance();
    
    // Adiciona o link do relatório na página de relatórios de vendas
    if (has_permission('reports', '', 'view')) {
        // Hook para adicionar CSS e JS
        hooks()->add_action('app_admin_head', 'relatorioitensclientes_add_assets');
        
        // Hook para adicionar o link via JavaScript
        hooks()->add_action('app_admin_footer', 'relatorioitensclientes_add_link_script');
    }
}

function relatorioitensclientes_add_assets()
{
    $CI = &get_instance();
    $current_url = $CI->uri->uri_string();
    
    if (strpos($current_url, 'reports/sales') !== false) {
        echo '<style>
        .relatorio-itens-cliente-link {
            display: block;
            padding: 10px 15px;
            margin-bottom: 2px;
            color: #333;
            text-decoration: none;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .relatorio-itens-cliente-link:hover {
            background-color: #e9ecef;
            color: #333;
            text-decoration: none;
        }
        .relatorio-itens-cliente-link i {
            margin-right: 8px;
            color: #007bff;
        }
        </style>';
    }
}

function relatorioitensclientes_add_link_script()
{
    $CI = &get_instance();
    $current_url = $CI->uri->uri_string();
    
    if (strpos($current_url, 'reports/sales') !== false) {
        echo '<script>
        $(document).ready(function() {
            function addReportLink() {
                if ($(".relatorio-itens-cliente-link").length > 0) return;
                
                var reportLink = $("<a href=\"" + "' . admin_url('reports/sales?report=relatorio_itens_por_cliente') . '" + "\" class=\"relatorio-itens-cliente-link\"><i class=\"fa fa-list-alt\"></i> Relatório de Itens por Cliente</a>");
                
                var selectors = [".list-group", ".nav-pills", ".nav-tabs", ".col-md-3", ".col-md-4"];
                var added = false;
                
                for (var i = 0; i < selectors.length; i++) {
                    var element = $(selectors[i]).first();
                    if (element.length > 0 && element.find("a").length > 0) {
                        element.append(reportLink);
                        added = true;
                        break;
                    }
                }
                
                if (!added) {
                    var newSection = $("<div class=\"col-md-3\"><div class=\"list-group\"></div></div>");
                    newSection.find(".list-group").append(reportLink);
                    $(".row").first().append(newSection);
                }
            }
            
            setTimeout(addReportLink, 1000);
            $(document).on("DOMNodeInserted", function() {
                setTimeout(addReportLink, 500);
            });
        });
        </script>';
    }
}

// Hook para interceptar o carregamento do relatório
hooks()->add_action('before_render_sales_reports_content', 'relatorioitensclientes_load_report_content');

function relatorioitensclientes_load_report_content()
{
    $CI = &get_instance();
    $report = $CI->input->get('report');
    
    if ($report === 'relatorio_itens_por_cliente' && has_permission('reports', '', 'view')) {
        // Carrega o conteúdo do nosso relatório
        $CI->load->model('relatorioitensclientes_model');
        
        $filters = [];
        $filters['from'] = $CI->input->get('from') ?: '';
        $filters['to']   = $CI->input->get('to') ?: '';
        $filters['agent_id'] = $CI->input->get('agent_id') ?: '';
        $filters['status']   = $CI->input->get('status') ?: '';
        $filters['search']   = $CI->input->get('search') ?: '';

        $data['filters'] = $filters;
        $data['agents']  = $CI->relatorioitensclientes_model->get_sale_agents();
        $data['rows']    = $CI->relatorioitensclientes_model->get_itens_vendidos($filters);
        
        $CI->load->view('relatorioitensclientes/sales_report_content', $data);
        return true; // Impede o carregamento do conteúdo padrão
    }
    
    return false;
}


// Module information functions
function relatorioitensclientes_module_name()
{
    return RELATORIOITENSCLIENTES_MODULE_NAME;
}

function relatorioitensclientes_module_description()
{
    return RELATORIOITENSCLIENTES_MODULE_DESCRIPTION;
}

function relatorioitensclientes_module_version()
{
    return RELATORIOITENSCLIENTES_MODULE_VERSION;
}

// Optional activation hook (keeps compatibility)
register_activation_hook(RELATORIOITENSCLIENTES_MODULE, 'relatorioitensclientes_activation_hook');
function relatorioitensclientes_activation_hook() {
    // nothing to run on activation
}
