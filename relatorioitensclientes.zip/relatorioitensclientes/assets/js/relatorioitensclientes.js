// JavaScript para adicionar o link do relatório na página de relatórios de vendas
(function() {
    'use strict';
    
    function addReportLink() {
        // Verifica se já foi adicionado
        if ($('.relatorio-itens-cliente-link').length > 0) {
            return;
        }
        
        var reportLink = $('<a href="' + window.location.origin + '/admin/reports/sales?report=relatorio_itens_por_cliente" class="relatorio-itens-cliente-link"><i class="fa fa-list-alt"></i> Relatório de Itens por Cliente</a>');
        
        // Procura pela estrutura de relatórios
        var selectors = [
            '.list-group',
            '.nav-pills',
            '.nav-tabs',
            '.panel-body .row .col-md-3',
            '.panel-body .row .col-md-4',
            '.col-md-3',
            '.col-md-4'
        ];
        
        var added = false;
        
        for (var i = 0; i < selectors.length; i++) {
            var element = $(selectors[i]).first();
            if (element.length > 0 && element.find('a').length > 0) {
                element.append(reportLink);
                added = true;
                break;
            }
        }
        
        // Se não encontrou lugar apropriado, cria uma nova seção
        if (!added) {
            var newSection = $('<div class="col-md-3"><div class="list-group"></div></div>');
            newSection.find('.list-group').append(reportLink);
            $('.row').first().append(newSection);
        }
    }
    
    // Executa quando a página carrega
    $(document).ready(function() {
        setTimeout(addReportLink, 1000);
    });
    
    // Executa quando há mudanças no DOM (para páginas AJAX)
    $(document).on('DOMNodeInserted', function() {
        setTimeout(addReportLink, 500);
    });
    
    // Executa quando a página é carregada via AJAX
    $(document).ajaxComplete(function() {
        setTimeout(addReportLink, 500);
    });
})();
